from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma
import os

CHROMA_DIR = os.getenv("CHROMA_DB_DIR", "./chroma_db")

def build_or_load_index(docs, persist=True):
    emb = OpenAIEmbeddings()
    vectordb = Chroma.from_documents(docs, emb, persist_directory=CHROMA_DIR)
    if persist:
        vectordb.persist()
    return vectordb

def get_retriever(vectordb, k=5):
    return vectordb.as_retriever(search_kwargs={"k": k})
