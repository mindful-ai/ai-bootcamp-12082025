# Word Jumble Game

A simple command-line word jumble game built with Python.

## Installation
```bash
pip install .